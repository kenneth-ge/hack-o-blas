#ifndef TT_KERNEL_INCLUDES
#define TT_KERNEL_INCLUDES

#include <cuda.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>

#endif

void unload_matmul_fp16_c0d4828d_0d1d2d3456d7c8d9c10d11c(void);
void load_matmul_fp16_c0d4828d_0d1d2d3456d7c8d9c10d11c(void);
// tt-linker: matmul_fp16_c0d4828d_0d1d2d3456d7c8d9c10d11c:CUdeviceptr C, CUdeviceptr A, CUdeviceptr B, int32_t M, int32_t N, int32_t K, int32_t stride_cm, int32_t stride_cn, int32_t stride_am, int32_t stride_ak, int32_t stride_bk, int32_t stride_bn:32x32x32_warps1xstages3
CUresult matmul_fp16_c0d4828d_0d1d2d3456d7c8d9c10d11c(CUstream stream, CUdeviceptr C, CUdeviceptr A, CUdeviceptr B, int32_t M, int32_t N, int32_t K, int32_t stride_cm, int32_t stride_am, int32_t stride_bk);
